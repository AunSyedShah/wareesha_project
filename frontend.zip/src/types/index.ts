export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'exhibitor' | 'attendee';
  company?: string;
  avatar?: string;
  createdAt: Date;
}

export interface Expo {
  id: string;
  title: string;
  description: string;
  date: Date;
  endDate: Date;
  location: string;
  theme: string;
  maxExhibitors: number;
  registrationDeadline: Date;
  status: 'upcoming' | 'active' | 'completed';
  floorPlan: FloorPlan;
  createdBy: string;
  createdAt: Date;
}

export interface FloorPlan {
  width: number;
  height: number;
  booths: Booth[];
}

export interface Booth {
  id: string;
  number: string;
  x: number;
  y: number;
  width: number;
  height: number;
  price: number;
  status: 'available' | 'reserved' | 'occupied';
  exhibitorId?: string;
  category?: string;
}

export interface Exhibitor {
  id: string;
  userId: string;
  companyName: string;
  description: string;
  logo?: string;
  website?: string;
  contactPerson: string;
  email: string;
  phone: string;
  products: string[];
  services: string[];
  boothIds: string[];
  expoId: string;
  status: 'pending' | 'approved' | 'rejected';
  appliedAt: Date;
}

export interface Schedule {
  id: string;
  expoId: string;
  title: string;
  description: string;
  startTime: Date;
  endTime: Date;
  speaker?: string;
  location: string;
  category: string;
  maxAttendees?: number;
  registeredAttendees: string[];
}

export interface Message {
  id: string;
  fromId: string;
  toId: string;
  content: string;
  timestamp: Date;
  read: boolean;
}

export interface Registration {
  id: string;
  userId: string;
  expoId: string;
  registeredAt: Date;
  sessions: string[];
}